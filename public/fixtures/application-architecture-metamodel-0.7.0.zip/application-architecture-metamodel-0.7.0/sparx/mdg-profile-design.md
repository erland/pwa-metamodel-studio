# Sparx EA / MDG-profildesign

## Profil
- Profilnamn: `AppArch`
- MDG-id: `ApplicationArchitecture`
- Namespace: `AppArch`
- Version: `0.5.0`

## Elementstereotyper
| Canonical typ | EA metaclass | Stereotyp |
|---|---|---|
| Application System | Component | `AppArch::ApplicationSystem` |
| Application Component | Component | `AppArch::ApplicationComponent` |
| Application Service | Class | `AppArch::ApplicationService` |
| Application Interface | Interface | `AppArch::ApplicationInterface` |
| Application Event | Signal | `AppArch::ApplicationEvent` |
| Data Object | DataObject | `AppArch::DataObject` |
| Technology Service | Component | `AppArch::TechnologyService` |
| Technology Node | Node | `AppArch::TechnologyNode` |

## Connectorstereotyper
Canonical relationer mappas till ett litet antal återanvändbara stereotyper:
- `ComposedOf` på UML Composition
- `Realizes` på UML Realization
- `ExposedVia` på UML Dependency
- `Produces` på UML Dependency
- `Consumes` på UML Dependency
- `Uses` på UML Dependency
- `Manages` på UML Association
- `DeployedOn` på UML Deployment

Käll- och måltyper ska begränsas i profilen så att connectorn bara kan användas enligt canonical-reglerna.

## Tagged values
Canonical properties mappas till tagged values. Enumerations ska realiseras som
MDG-enumerationer eller profile-defined tagged value types där det är praktiskt möjligt.

## Toolbox
Toolboxen delas upp i:
1. Application Structure
2. Application Behavior
3. Application Integration
4. Information
5. Technology
6. Relationships

## Diagramprofiler
Tre diagramtyper skapas:
- Application Landscape
- Application Architecture
- Solution Architecture

De ska använda samma stereotyper men olika palett/urval och olika modellrekommendationer.

## Shapescripts
Canonical notation ska implementeras som shapescripts eller motsvarande visuella
stereotypinställningar. Färg och ikon är stödjande; stereotypnamn och elementtyp ska
fortsatt vara tydliga.

## Viktig designprincip
MDG-profilen är en adapter. Canonical YAML förblir sanningskälla och ska inte förändras
för att passa begränsningar i Sparx EA.
