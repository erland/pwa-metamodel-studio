# Referensdokumentation - Applikationsarkitektur

Version: **0.7.0**

Teknisk referens för metamodellens typer, relationer, metadata, viewpoints och notation.

## Elementtyper

| ID | Namn | Kind | Beskrivning |
|---|---|---|---|
| `application_system` | Application System | structure | Ett komplett och förvaltningsmässigt identifierbart applikationssystem. Används som den högsta applikationslogiska behållaren i modellen. |
| `application_component` | Application Component | structure | En logiskt avgränsad del av ett applikationssystem. Komponenten kan brytas ned hierarkiskt och används när intern struktur behöver modelleras. |
| `application_service` | Application Service | behavior | En avgränsad applikationsfunktion som erbjuds till en konsument. Tjänsten beskriver vad som erbjuds, inte hur det implementeras. |
| `application_interface` | Application Interface | structure | En explicit åtkomstpunkt eller ett kontrakt genom vilket en eller flera applikationstjänster exponeras eller konsumeras. |
| `application_event` | Application Event | behavior | En betydelsefull, namngiven händelse som publiceras eller konsumeras av applikationstjänster. Händelsen uttrycks som något som har inträffat. |
| `data_object` | Data Object | artifact | Ett logiskt informationsobjekt som skapas, används eller förvaltas av applikationsarkitekturen. Det representerar information, inte fysisk lagring. |
| `technology_service` | Technology Service | behavior | En teknisk förmåga eller tjänst som konsumeras av applikationskomponenter eller applikationstjänster, exempelvis meddelandeförmedling eller identitet. |
| `technology_node` | Technology Node | node | En teknisk exekverings- eller driftsmiljö där applikationskomponenter eller tekniska tjänster är installerade eller körs. |

## Relationstyper

| ID | Från | Till | Kardinalitet | Kind | Beskrivning |
|---|---|---|---|---|---|
| `system_composed_of_component` | Application System | Application Component | 1 -> 0..* | structural | Anger att ett applikationssystem strukturellt består av applikationskomponenter. |
| `component_composed_of_component` | Application Component | Application Component | 1 -> 0..* | structural | Anger hierarkisk nedbrytning av en applikationskomponent i underkomponenter. |
| `system_realizes_service` | Application System | Application Service | 1 -> 0..* | realization | Anger att ett system direkt realiserar en applikationstjänst när komponentnivån medvetet utelämnas. |
| `component_realizes_service` | Application Component | Application Service | 1 -> 0..* | realization | Anger att en applikationskomponent implementerar och erbjuder en applikationstjänst. |
| `service_exposed_via_interface` | Application Service | Application Interface | 1 -> 0..* | association | Anger att en applikationstjänst görs åtkomlig via ett explicit applikationsgränssnitt. |
| `service_produces_event` | Application Service | Application Event | 1 -> 0..* | flow | Anger att en applikationstjänst publicerar eller orsakar en namngiven applikationshändelse. |
| `service_consumes_event` | Application Service | Application Event | 1 -> 0..* | flow | Anger att en applikationstjänst reagerar på eller konsumerar en namngiven applikationshändelse. |
| `service_uses_technology_service` | Application Service | Technology Service | 1 -> 0..* | dependency | Anger att en applikationstjänst är beroende av en teknisk tjänst. |
| `component_uses_technology_service` | Application Component | Technology Service | 1 -> 0..* | dependency | Anger ett tekniskt beroende som gäller komponenten som helhet och inte bara en enskild applikationstjänst. |
| `system_manages_data` | Application System | Data Object | 1 -> 0..* | association | Anger övergripande systemansvar eller förvaltningsansvar för ett logiskt informationsobjekt. |
| `component_manages_data` | Application Component | Data Object | 1 -> 0..* | association | Anger att en komponent har ett tydligt ansvar för hantering av ett informationsobjekt inom systemet. |
| `service_uses_data` | Application Service | Data Object | 1 -> 0..* | dependency | Anger att en applikationstjänst läser eller använder ett informationsobjekt utan att relationen uttrycker ägarskap. |
| `service_produces_data` | Application Service | Data Object | 1 -> 0..* | flow | Anger att en applikationstjänst skapar eller väsentligt förändrar ett informationsobjekt. |
| `component_deployed_on_node` | Application Component | Technology Node | 1 -> 0..* | dependency | Anger att en applikationskomponent installeras eller körs på en teknisk nod. |
| `technology_service_deployed_on_node` | Technology Service | Technology Node | 1 -> 0..* | dependency | Anger att en teknisk tjänst tillhandahålls från eller körs på en teknisk nod. |
| `system_uses_service` | Application System | Application Service | 1 -> 0..* | dependency | Anger att ett applikationssystem konsumerar en applikationstjänst. |
| `component_uses_service` | Application Component | Application Service | 1 -> 0..* | dependency | Anger att en applikationskomponent konsumerar en applikationstjänst. |
| `system_uses_interface` | Application System | Application Interface | 1 -> 0..* | dependency | Anger att ett applikationssystem använder ett explicit applikationsgränssnitt. |
| `component_uses_interface` | Application Component | Application Interface | 1 -> 0..* | dependency | Anger att en applikationskomponent använder ett explicit applikationsgränssnitt. |

## Property definitions

| ID | Namn | Typ | Kardinalitet | Obligatorisk |
|---|---|---|---|---|
| `external_id` | External ID | `qualified_identifier` | 0..1 | Nej |
| `owner` | Owner | `string` | 0..1 | Nej |
| `lifecycle` | Lifecycle Status | `lifecycle_status` | 1 | Ja |
| `criticality` | Criticality | `criticality` | 0..1 | Nej |
| `documentation_uri` | Documentation URI | `uri` | 0..1 | Nej |
| `interface_kind` | Interface Kind | `interface_kind` | 1 | Ja |
| `protocol` | Protocol | `string` | 0..1 | Nej |
| `interaction_style` | Interaction Style | `interaction_style` | 0..1 | Nej |
| `schema_reference` | Schema Reference | `uri` | 0..1 | Nej |
| `event_version` | Event Version | `string` | 0..1 | Nej |
| `data_classification` | Data Classification | `data_classification` | 0..1 | Nej |
| `technology_product` | Technology/Product | `string` | 0..1 | Nej |
| `technology_version` | Technology Version | `string` | 0..1 | Nej |
| `environment` | Environment | `environment_type` | 0..1 | Nej |
| `location` | Location | `string` | 0..1 | Nej |

## Enumerations

### Lifecycle Status (`lifecycle_status`)

Livscykelstatus för ett arkitekturobjekt.

Planned, Active, Phasing out, Retired

### Criticality (`criticality`)

Övergripande verksamhets-/driftkritikalitet.

Low, Medium, High, Mission critical

### Interface Kind (`interface_kind`)

API, User interface, File, Messaging, Database, Other

### Interaction Style (`interaction_style`)

Synchronous, Asynchronous, Batch, Human interaction, Other

### Data Classification (`data_classification`)

Generisk informationsklassning; kan senare mappas mot lokal klassningsmodell.

Public, Internal, Restricted, Highly restricted

### Environment Type (`environment_type`)

Development, Test, Staging, Production, Shared/unspecified

## Property sets

### Core Metadata (`core_metadata`)

Gemensamma metadata för alla objekttyper.

Properties: `external_id`, `owner`, `lifecycle`, `documentation_uri`

### Criticality Metadata (`criticality_metadata`)

Kritikalitetsmetadata för objekt där detta är relevant.

Properties: `criticality`

### Interface Metadata (`interface_metadata`)

Properties: `interface_kind`, `protocol`, `interaction_style`, `schema_reference`

### Event Metadata (`event_metadata`)

Properties: `event_version`, `schema_reference`

### Data Metadata (`data_metadata`)

Properties: `data_classification`

### Technology Metadata (`technology_metadata`)

Properties: `technology_product`, `technology_version`

### Node Metadata (`node_metadata`)

Properties: `environment`, `location`, `technology_product`, `technology_version`

## Viewpoints

### Application Landscape (`application_landscape`)

Översiktsvy över system och systemöverskridande beroenden, utan intern komponentstruktur.

Syfte: Besvara vilka system som finns, vilka externa tjänster/gränssnitt de använder och vilket informationsansvar som behöver synliggöras.

### Application Architecture (`application_architecture_view`)

Logisk vy över ett systems interna struktur med komponenter, tjänster, gränssnitt, events och information.

Syfte: Besvara hur ett system är strukturerat och vilka applikationslogiska ansvar och interaktioner som finns.

### Solution Architecture (`solution_architecture`)

Implementeringsnära vy som kompletterar applikationsstrukturen med tekniska tjänster och noder.

Syfte: Besvara hur lösningen realiseras, kommunicerar och körs utan att bli en fysisk inventering av all infrastruktur.

## Notation

| Typ | Shape | Visuella hints |
|---|---|---|
| `application_system` | rounded_rectangle | fill=#D9ECFF, line=#2E75B6, text=#17365D, icon=grid, corner_style=rounded |
| `application_component` | rounded_rectangle | fill=#E2F0D9, line=#548235, text=#1F4E23, icon=cube, corner_style=rounded |
| `application_service` | rounded_rectangle | fill=#FCE4D6, line=#C00000, text=#7F0000, icon=gear, corner_style=rounded |
| `application_interface` | rounded_rectangle | fill=#E4DFEC, line=#7030A0, text=#3F1764, icon=share, corner_style=rounded |
| `application_event` | rounded_rectangle | fill=#E4DFEC, line=#7030A0, text=#3F1764, icon=lightning, corner_style=rounded |
| `data_object` | rounded_rectangle | fill=#FFF2CC, line=#BF9000, text=#7F6000, icon=document, corner_style=rounded |
| `technology_service` | rounded_rectangle | fill=#DDEBF7, line=#2E75B6, text=#17365D, icon=server_stack, corner_style=rounded |
| `technology_node` | rounded_rectangle | fill=#DDEBF7, line=#2E75B6, text=#17365D, icon=server, corner_style=rounded |
| `system_composed_of_component` | line | line_style=solid, line=#000000, source_marker=filled_diamond, target_marker=none |
| `component_composed_of_component` | line | line_style=solid, line=#000000, source_marker=filled_diamond, target_marker=none |
| `system_realizes_service` | line | line_style=dashed, line=#000000, source_marker=none, target_marker=hollow_triangle |
| `component_realizes_service` | line | line_style=dashed, line=#000000, source_marker=none, target_marker=hollow_triangle |
| `service_exposed_via_interface` | line | line_style=dashed, line=#000000, source_marker=none, target_marker=open_arrow |
| `service_produces_event` | line | line_style=dashed, line=#000000, source_marker=none, target_marker=open_arrow |
| `service_consumes_event` | line | line_style=dashed, line=#000000, source_marker=none, target_marker=open_arrow |
| `service_uses_technology_service` | line | line_style=dashed, line=#000000, source_marker=none, target_marker=open_arrow |
| `component_uses_technology_service` | line | line_style=dashed, line=#000000, source_marker=none, target_marker=open_arrow |
| `system_manages_data` | line | line_style=dashed, line=#000000, source_marker=none, target_marker=open_arrow |
| `component_manages_data` | line | line_style=dashed, line=#000000, source_marker=none, target_marker=open_arrow |
| `service_uses_data` | line | line_style=dashed, line=#000000, source_marker=none, target_marker=open_arrow |
| `service_produces_data` | line | line_style=dashed, line=#000000, source_marker=none, target_marker=open_arrow |
| `component_deployed_on_node` | line | line_style=dashed, line=#000000, source_marker=none, target_marker=open_arrow |
| `technology_service_deployed_on_node` | line | line_style=dashed, line=#000000, source_marker=none, target_marker=open_arrow |
| `system_uses_service` | line | line_style=dashed, line=#000000, source_marker=none, target_marker=open_arrow |
| `component_uses_service` | line | line_style=dashed, line=#000000, source_marker=none, target_marker=open_arrow |
| `system_uses_interface` | line | line_style=dashed, line=#000000, source_marker=none, target_marker=open_arrow |
| `component_uses_interface` | line | line_style=dashed, line=#000000, source_marker=none, target_marker=open_arrow |
