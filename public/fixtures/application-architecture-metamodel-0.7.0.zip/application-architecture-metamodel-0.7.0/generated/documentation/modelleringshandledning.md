# Modelleringshandledning - Applikationsarkitektur

Version: **0.7.0**

Denna handledning beskriver hur metamodellen ska användas i praktisk modellering. Canonical YAML är sanningskälla; detta dokument är genererad användardokumentation.

## Grundprinciper

- Modellera semantik före verktygsspecifik notation.
- Använd lägsta detaljnivå som besvarar vyens frågor.
- Skilj ansvar (manages) från användning (uses) och produktion/förändring (produces).
- Skilj producent och konsument för events.
- Modellera tjänsten som vad som erbjuds och gränssnittet som hur den görs åtkomlig.
- Använd systemnivåns realization endast när komponentnivån medvetet utelämnas.
- Placera tekniska beroenden på lägsta relevanta nivå utan att duplicera samma beroende i onödan.
- Metadata ska stödja styrning och analys, inte duplicera information som redan uttrycks av relationer.
- Obligatorisk metadata hålls medvetet liten: lifecycle för alla element och interface_kind för Application Interface.
- Organisationsspecifika klassningsskalor och registeridentifierare bör kunna bytas utan att ändra kärnsemantiken.
- Notationens färger och ikoner får stödja igenkänning men får aldrig vara enda bärare av semantik.
- Relationssemantik ska främst framgå av relationstyp och etikett; linjestil används som sekundärt visuellt stöd.
- Samma objekttyp ska ha samma grundnotation i alla viewpoints.
- Viewpoints får styra urval och detaljnivå men ska inte ändra den underliggande typen.

## Namngivning

- System och komponenter namnges med etablerade verksamhetsnamn.
- Tjänster namnges som verbfraser.
- Events namnges som inträffade händelser.

## Objekttyper

### Application System

Ett komplett och förvaltningsmässigt identifierbart applikationssystem. Används som den högsta applikationslogiska behållaren i modellen.

**Syfte:** Representera ett komplett system.

**Använd när:**
- Objektet förvaltas och förstås som ett eget system.

**Använd inte när:**
- Objektet endast är en intern del av ett system.

**Exempel:** Deklarationssystem

**Metadata:**
- Core Metadata: External ID, Owner, Lifecycle Status, Documentation URI
- Criticality Metadata: Criticality

### Application Component

En logiskt avgränsad del av ett applikationssystem. Komponenten kan brytas ned hierarkiskt och används när intern struktur behöver modelleras.

**Syfte:** Representera en logiskt avgränsad del av ett system.

**Använd när:**
- Intern struktur behöver visas.

**Exempel:** Riskhantering

**Metadata:**
- Core Metadata: External ID, Owner, Lifecycle Status, Documentation URI
- Criticality Metadata: Criticality

### Application Service

En avgränsad applikationsfunktion som erbjuds till en konsument. Tjänsten beskriver vad som erbjuds, inte hur det implementeras.

**Syfte:** Representera en erbjuden funktion eller tjänst.

**Använd när:**
- Man behöver beskriva vad ett system eller en komponent erbjuder.

**Exempel:** Ta emot deklaration

**Metadata:**
- Core Metadata: External ID, Owner, Lifecycle Status, Documentation URI
- Criticality Metadata: Criticality

### Application Interface

En explicit åtkomstpunkt eller ett kontrakt genom vilket en eller flera applikationstjänster exponeras eller konsumeras.

**Syfte:** Representera exponerings- eller konsumtionsgränssnitt.

**Använd när:**
- Kommunikationskontrakt eller kanal är relevant.

**Exempel:** Declaration API

**Metadata:**
- Core Metadata: External ID, Owner, Lifecycle Status, Documentation URI
- Interface Metadata: Interface Kind, Protocol, Interaction Style, Schema Reference

### Application Event

En betydelsefull, namngiven händelse som publiceras eller konsumeras av applikationstjänster. Händelsen uttrycks som något som har inträffat.

**Syfte:** Representera en producerad eller konsumerad händelse.

**Exempel:** Declaration Received

**Metadata:**
- Core Metadata: External ID, Owner, Lifecycle Status, Documentation URI
- Event Metadata: Event Version, Schema Reference

### Data Object

Ett logiskt informationsobjekt som skapas, används eller förvaltas av applikationsarkitekturen. Det representerar information, inte fysisk lagring.

**Syfte:** Representera logisk information som hanteras.

**Exempel:** Deklaration, Riskprofil

**Metadata:**
- Core Metadata: External ID, Owner, Lifecycle Status, Documentation URI
- Data Metadata: Data Classification

### Technology Service

En teknisk förmåga eller tjänst som konsumeras av applikationskomponenter eller applikationstjänster, exempelvis meddelandeförmedling eller identitet.

**Syfte:** Representera tekniska plattformstjänster som lösningen använder.

**Exempel:** Kafka, Databas, Identity Provider

**Metadata:**
- Core Metadata: External ID, Owner, Lifecycle Status, Documentation URI
- Criticality Metadata: Criticality
- Technology Metadata: Technology/Product, Technology Version

### Technology Node

En teknisk exekverings- eller driftsmiljö där applikationskomponenter eller tekniska tjänster är installerade eller körs.

**Syfte:** Representera teknisk exekveringsmiljö.

**Exempel:** Kubernetes-kluster, Virtuell server

**Metadata:**
- Core Metadata: External ID, Owner, Lifecycle Status, Documentation URI
- Node Metadata: Environment, Location, Technology/Product, Technology Version

## Relationer

| Från | Relation | Till | Betydelse |
|---|---|---|---|
| Application System | consists of | Application Component | Anger att ett applikationssystem strukturellt består av applikationskomponenter. |
| Application Component | consists of | Application Component | Anger hierarkisk nedbrytning av en applikationskomponent i underkomponenter. |
| Application System | realizes | Application Service | Anger att ett system direkt realiserar en applikationstjänst när komponentnivån medvetet utelämnas. |
| Application Component | realizes | Application Service | Anger att en applikationskomponent implementerar och erbjuder en applikationstjänst. |
| Application Service | exposes via | Application Interface | Anger att en applikationstjänst görs åtkomlig via ett explicit applikationsgränssnitt. |
| Application Service | produces | Application Event | Anger att en applikationstjänst publicerar eller orsakar en namngiven applikationshändelse. |
| Application Service | consumes | Application Event | Anger att en applikationstjänst reagerar på eller konsumerar en namngiven applikationshändelse. |
| Application Service | uses | Technology Service | Anger att en applikationstjänst är beroende av en teknisk tjänst. |
| Application Component | uses | Technology Service | Anger ett tekniskt beroende som gäller komponenten som helhet och inte bara en enskild applikationstjänst. |
| Application System | manages | Data Object | Anger övergripande systemansvar eller förvaltningsansvar för ett logiskt informationsobjekt. |
| Application Component | manages | Data Object | Anger att en komponent har ett tydligt ansvar för hantering av ett informationsobjekt inom systemet. |
| Application Service | uses | Data Object | Anger att en applikationstjänst läser eller använder ett informationsobjekt utan att relationen uttrycker ägarskap. |
| Application Service | produces | Data Object | Anger att en applikationstjänst skapar eller väsentligt förändrar ett informationsobjekt. |
| Application Component | deployed on | Technology Node | Anger att en applikationskomponent installeras eller körs på en teknisk nod. |
| Technology Service | deployed on | Technology Node | Anger att en teknisk tjänst tillhandahålls från eller körs på en teknisk nod. |
| Application System | uses | Application Service | Anger att ett applikationssystem konsumerar en applikationstjänst. |
| Application Component | uses | Application Service | Anger att en applikationskomponent konsumerar en applikationstjänst. |
| Application System | uses | Application Interface | Anger att ett applikationssystem använder ett explicit applikationsgränssnitt. |
| Application Component | uses | Application Interface | Anger att en applikationskomponent använder ett explicit applikationsgränssnitt. |

## Viewpoints

### Application Landscape

Översiktsvy över system och systemöverskridande beroenden, utan intern komponentstruktur.

**Syfte:** Besvara vilka system som finns, vilka externa tjänster/gränssnitt de använder och vilket informationsansvar som behöver synliggöras.

**Typiska intressenter:** Enterprise Architect, Application Architect

**Tillåtna element:** Application System, Application Service, Application Interface, Data Object

**Tillåtna relationer:** realizes, exposes via, uses, uses, manages

### Application Architecture

Logisk vy över ett systems interna struktur med komponenter, tjänster, gränssnitt, events och information.

**Syfte:** Besvara hur ett system är strukturerat och vilka applikationslogiska ansvar och interaktioner som finns.

**Typiska intressenter:** Application Architect, Solution Architect

**Tillåtna element:** Application System, Application Component, Application Service, Application Interface, Application Event, Data Object

**Tillåtna relationer:** consists of, consists of, realizes, realizes, exposes via, produces, consumes, manages, manages, uses, produces, uses, uses, uses, uses

### Solution Architecture

Implementeringsnära vy som kompletterar applikationsstrukturen med tekniska tjänster och noder.

**Syfte:** Besvara hur lösningen realiseras, kommunicerar och körs utan att bli en fysisk inventering av all infrastruktur.

**Typiska intressenter:** Solution Architect, Developer, Platform Architect

**Tillåtna element:** Application Component, Application Service, Application Interface, Application Event, Data Object, Technology Service, Technology Node

**Tillåtna relationer:** consists of, realizes, exposes via, produces, consumes, uses, uses, manages, uses, produces, deployed on, deployed on, uses, uses

## Regler och kvalitetskontroller

### Ingen cyklisk komponenthierarki

**Nivå:** error

Composition mellan Application Component får inte skapa en cykel, direkt eller indirekt.

**Meddelande:** Komponenthierarkin får inte vara cyklisk.

### Komponent bör ha en entydig ägarhierarki

**Nivå:** warning

En Application Component bör ingå i exakt en kompositionshierarki som ytterst leder till ett Application System.

**Meddelande:** Komponenten bör ha en entydig kompositionsväg till ett applikationssystem.

### Tjänst bör realiseras

**Nivå:** warning

En Application Service bör realiseras av minst en Application Component eller, när komponentnivån medvetet utelämnas, av ett Application System.

**Meddelande:** Tjänsten saknar realiserande system eller komponent.

### Undvik dubbel realisering på system- och komponentnivå

**Nivå:** warning

Samma Application Service bör normalt inte realiseras både direkt av ett Application System och av dess Application Components.

**Meddelande:** Tjänsten verkar vara realiserad på både system- och komponentnivå.

### Gränssnitt bör exponera tjänst

**Nivå:** warning

Ett Application Interface bör exponera minst en Application Service via exposes via.

**Meddelande:** Gränssnittet saknar exponerad tjänst.

### Händelse bör ha producent

**Nivå:** warning

Ett Application Event bör produceras av minst en Application Service.

**Meddelande:** Händelsen saknar producerande tjänst.

### Händelse bör ha konsument eller markerad extern gräns

**Nivå:** warning

Ett Application Event bör konsumeras av minst en Application Service, om det inte avsiktligt lämnar den modellerade avgränsningen.

**Meddelande:** Händelsen saknar konsument i den modellerade avgränsningen.

### Informationsansvar ska skiljas från användning

**Nivå:** warning

Relationen manages ska användas för ansvar/förvaltning; läsning och produktion ska uttryckas med uses respektive produces.

**Meddelande:** Kontrollera att informationsansvar inte har modellerats som vanlig användning eller tvärtom.

### Deployment används endast för faktisk körmiljö

**Nivå:** warning

deployed on ska endast användas när relationen avser faktisk eller avsedd exekverings-/driftsmiljö, inte allmän teknikassociation.

**Meddelande:** Kontrollera att deployed on verkligen avser exekverings- eller driftsmiljö.

### Livscykelstatus är obligatorisk

**Nivå:** error

Alla element ska ha lifecycle metadata. Standardvärdet active får användas när annan status inte är känd.

**Meddelande:** Element saknar obligatorisk lifecycle-status.

### Interface Kind är obligatorisk

**Nivå:** error

Application Interface ska ha interface_kind.

**Meddelande:** Application Interface saknar interface_kind.

### Informationsklassning bör anges när relevant

**Nivå:** warning

Data Object bör ha data_classification när informationsklassning är relevant för arkitekturbeslut eller styrning.

**Meddelande:** Överväg att ange informationsklassning.

### Protokoll bör anges för tekniska gränssnitt

**Nivå:** warning

Protocol bör anges för API-, file-, messaging- och database-interface när informationen är känd.

**Meddelande:** Tekniskt gränssnitt saknar protokoll.

## Patterns

### Tjänst med explicit gränssnitt

Application Component realiserar Application Service som exponeras via Application Interface.

### Händelsedriven interaktion

En tjänst producerar ett Application Event som konsumeras av en annan tjänst.

### Informationsansvar

System eller komponent manages Data Object; tjänster uses/produces samma Data Object för faktisk informationsanvändning.

### Teknisk realisering

Application Component använder Technology Service och är deployed on Technology Node.

## Anti-patterns

### Tjänst modellerad som komponent

Undvik att använda Application Component för en erbjuden funktion bara för att funktionen har en egen implementation.

### Gränssnitt och tjänst sammanblandas

Ett API eller annat interface beskriver åtkomst/kontrakt; Application Service beskriver den erbjudna funktionen.

### Teknik modellerad som applikationskomponent

Kafka, databastjänster och identitetstjänster modelleras normalt som Technology Service, inte Application Component.

### Samma beroende på flera nivåer

Undvik att modellera samma tekniska eller tjänstebaserade beroende på både system-, komponent- och tjänstenivå om det inte uttrycker olika semantik.

## Vanliga frågor

### När ska Application System realisera en tjänst direkt?

När vyn avsiktligt är förenklad och komponentnivån inte modelleras. I detaljerade arkitekturvyer bör tjänsten normalt realiseras av en Application Component.

### Vad är skillnaden mellan Application Service och Application Interface?

Service beskriver vad som erbjuds. Interface beskriver hur tjänsten görs åtkomlig eller konsumeras.

### Vad är skillnaden mellan manages och uses för Data Object?

manages uttrycker ansvar eller förvaltning. uses uttrycker att informationen läses/används i ett beteende.

### Varför är inte owner obligatoriskt?

Ägarskap är viktigt men kan saknas i tidiga eller externa modeller. Därför är owner rekommenderad men inte ett blockerande krav i kärnmetamodellen.

### Varför är lifecycle obligatoriskt?

Livscykelstatus behövs för att kunna skilja planerade, aktiva och avvecklade objekt i samma arkitekturmodell och har ett stabilt värde även i översiktsvyer.

### Ska Data Classification ersätta organisationens informationsklassningsmodell?

Nej. Den generiska enumerationen är ett startvärde och är avsedd att kunna ersättas eller mappas mot en lokal klassningsmodell.

### Måste färgerna användas exakt i alla verktyg?

Nej. Färgerna är en rekommenderad verktygsneutral profil. Om ett verktyg eller en tillgänglighetsprofil kräver andra färger ska typ, ikon, etikett och relation ändå bevara semantiken.

### Varför har Application Interface och Application Event samma färgfamilj?

De hör båda till integrations-/interaktionsområdet men skiljs med ikon, namn och relationssemantik. Verktygsspecifika profiler kan ge ytterligare visuell separation.
