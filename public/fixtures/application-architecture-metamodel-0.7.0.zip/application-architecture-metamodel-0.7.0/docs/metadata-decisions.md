# Metadata- och propertybeslut – version 0.3.0

## Princip
Metamodellen ska ha tillräcklig metadata för styrning, filtrering och export till verktyg,
men inte bli ett systemregister i sig.

## Obligatoriskt
- `lifecycle` för alla element.
- `interface_kind` för `Application Interface`.

## Rekommenderat men inte obligatoriskt
- `owner`
- `external_id`
- `documentation_uri`
- `criticality`
- `data_classification`
- protokoll, kontraktsreferens och teknisk produkt/version där relevant.

## Varför owner inte är obligatoriskt
Modeller kan innehålla externa, preliminära eller ännu ej förvaltade objekt.
Owner är därför viktigt för kvalitetskontroll men ska inte blockera modellering.

## Varför lifecycle är obligatoriskt
Livscykelstatus är generell, stabil och central för arkitekturportföljanalys.
Standardvärdet är `active`.

## Informationsklassning
Den inkluderade klassningen är generisk och ska ses som en utbytbar startmodell.
En organisation kan senare ersätta eller mappa den mot sin egen klassningsmodell.

## Relationsmetadata
Relationsspecifik metadata införs inte ännu. Efter notation och Sparx EA-mappning
avgörs om exempelvis SLA eller säkerhetsattribut bör ligga på relation eller på ett explicit objekt.
