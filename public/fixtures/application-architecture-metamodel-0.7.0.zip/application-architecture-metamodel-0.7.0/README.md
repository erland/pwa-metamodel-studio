# Applikationsarkitektur – metamodell

Detta paket innehåller första validerade canonical-utkastet av metamodellen baserad på den bifogade skissen.

Canonical sanningskälla ligger i `canonical/`.
Nästa steg är att förfina semantik, kardinaliteter och modelleringsregler innan Sparx EA/MDG-mappning påbörjas.
