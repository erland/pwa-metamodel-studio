# MDG prototype – version 0.6.0

This release replaces the earlier conceptual `sparx/ea-mapping.yaml` with the generator-compatible
adapter under `platforms/sparx-ea/`.

The MDG is generated deterministically from:
- `canonical/`
- `platforms/sparx-ea/`

Automated gates:
1. canonical schema validation
2. canonical semantic validation
3. Sparx adapter schema/consistency validation
4. MDG generation
5. generated MDG structural validation
6. deterministic byte-for-byte generation check
7. XML well-formedness

A successful automated validation is **not** represented as proof that Enterprise Architect has
imported the file successfully. `tests/sparx-ea/manual-import-fixture.yaml` defines the remaining
manual interoperability checks.
