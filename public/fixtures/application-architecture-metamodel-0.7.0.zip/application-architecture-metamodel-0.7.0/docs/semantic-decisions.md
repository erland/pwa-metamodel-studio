# Semantiska beslut – version 0.2.0

## System och komponent
Application System är högsta applikationslogiska behållare. Application Component används för intern logisk struktur och bör ha en entydig kompositionsväg till ett system. Komponenthierarkin får inte vara cyklisk.

## Tjänst och gränssnitt
Application Service beskriver **vad** som erbjuds. Application Interface beskriver **hur** tjänsten görs åtkomlig eller konsumeras. Systemnivåns `realizes` används endast när komponentnivån medvetet utelämnas.

## Events
`produces` och `consumes` är separata relationer. Ett event bör normalt ha minst en producent och minst en konsument inom modellens avgränsning.

## Information
`manages` betyder ansvar/förvaltning. `uses` betyder läsning eller användning. `produces` betyder skapande eller väsentlig förändring. Data Object är logisk information och ska inte användas som synonym för databas eller fysisk lagring.

## Teknik och deployment
Technology Service beskriver en konsumerbar teknisk tjänst. Technology Node beskriver exekverings-/driftsmiljö. `deployed on` används endast för faktisk eller avsedd körmiljö.

## Kardinaliteter
Tillåtna relationstyper är fortsatt 0..* där valfrihet är relevant i canonical modellen. Striktare fullständighetskrav uttrycks som constraints, främst warnings, så att översiktsvyer inte blir ogiltiga bara för att de medvetet utelämnar detaljer.
