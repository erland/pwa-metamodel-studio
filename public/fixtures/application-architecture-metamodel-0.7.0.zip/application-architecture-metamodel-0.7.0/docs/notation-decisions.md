# Notationsbeslut – version 0.4.0

## Grundprincip
Notationen är verktygsneutral och ska kunna mappas till Sparx EA/MDG utan att canonical-modellen blir EA-beroende.

## Element
- Application System: blå, rundad rektangel, system/grid-symbol.
- Application Component: grön, rundad rektangel, kubsymbol.
- Application Service: röd, rundad rektangel, kugghjul.
- Application Interface: lila, rundad rektangel, gränssnitts-/share-symbol.
- Application Event: lila, rundad rektangel, blixtsymbol.
- Data Object: gul, rundad rektangel, dokumentsymbol.
- Technology Service: blå, rundad rektangel, server-stack.
- Technology Node: blå, rundad rektangel, server-/nodsymbol.

## Relationer
- Composition: heldragen linje med fylld diamant på helhetens sida.
- Realization: streckad linje med öppen triangel mot tjänsten.
- Övriga riktade relationer: streckad linje med öppen pil och tydlig etikett.

## Tillgänglighet
Färg får inte ensam uttrycka typ. Namn, ikon och relationstyp ska ge tillräcklig
information även i gråskala eller vid färgseendedefekter.

## Viewpoints
Viewpoints ändrar inte typsemantiken. De styr urval, relationer och lämplig detaljnivå.
