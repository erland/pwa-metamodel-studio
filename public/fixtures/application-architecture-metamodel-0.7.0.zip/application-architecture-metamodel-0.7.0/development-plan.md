# Utvecklingsplan

1. Etablera canonical kärnmodell från godkänd analys. **Klar**
2. Förfina semantik, kardinaliteter och modelleringsregler. **Klar**
3. Definiera properties och obligatoriska metadata. **Klar**
4. Definiera verktygsneutral notation. **Klar**
5. Definiera Sparx EA-mappning och MDG-profiler. **Klar**
6. Validera och generera första MDG-prototyp. **Klar (automatisk validering); manuell EA-import återstår**
7. Generera modelleringshandledning och referensdokumentation. **Klar**

Nästa rekommenderade aktivitet: genomför manuell import- och interoperabilitetstest i målversionen av Sparx Enterprise Architect och justera adapter/profil vid behov.
